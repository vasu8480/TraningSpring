package com.LabAssessment.model;


public interface Shape {
    double calArea(Double val);

    Integer getId();

    void setId(long id);

    void setArea(double area);

    Double getArea();
}
