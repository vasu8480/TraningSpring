package com.LabAssessment.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Triangle implements Shape {
    private Integer id;
    private double base;
    private double height;

    @Override
    public double calArea(Double val) {
        return 0.5 * base * height;
    }

    @Override
    public Integer getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = (int) id;
    }

    @Override
    public void setArea(double area) {

    }


    @Override
    public Double getArea() {
        return calArea(null);
    }
}
