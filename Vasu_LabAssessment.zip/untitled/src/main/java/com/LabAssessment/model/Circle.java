package com.LabAssessment.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Circle implements Shape {
    private Integer id;
    private double radius;

    @Override
    public double calArea(Double val) {
        return Math.PI * radius * radius;
    }

    @Override
    public Integer getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = (int) id;
    }

    @Override
    public void setArea(double area) {
        // Not applicable for Circle, area is calculated based on radius
    }

    @Override
    public Double getArea() {
        return calArea(null);
    }
}
