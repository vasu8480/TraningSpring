package com.LabAssessment.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Square implements Shape {
    private Integer id;
    private double side;

    @Override
    public double calArea(Double val) {
        return side * side;
    }

    @Override
    public Integer getId() {
        return id;
    }

    @Override
    public void setId(long id) {
        this.id = (int) id;
    }

    @Override
    public void setArea(double area) {
        // Not applicable for Square, area is calculated based on side
    }

    @Override
    public Double getArea() {
        return calArea(null);
    }
}
