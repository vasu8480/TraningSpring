package com.LabAssessment.config;

import com.LabAssessment.DAO.*;
import com.LabAssessment.model.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.*;
import java.util.List;

@Configuration
@ComponentScan(basePackages = {"com.LabAssessment"})
public class App {
    @Autowired
    private ShapeDao shapeDao;

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(App.class);
        App app = context.getBean(App.class);

        app.saveShapes();

        app.displayAllShapes();

        context.close();
    }

    public void saveShapes() {
        Shape triangle = new Triangle(1, 5, 7);
        Shape square = new Square(2, 4);
        Shape circle = new Circle(3, 3);
        Shape sphere = new Sphere(4, 2);

        shapeDao.saveShape(triangle);
        shapeDao.saveShape(square);
        shapeDao.saveShape(circle);
        shapeDao.saveShape(sphere);
    }

    public void displayAllShapes() {
        List<Shape> shapes = shapeDao.getAllShapes();
        System.out.println("Area of all shapes:");
        for (Shape shape : shapes) {
            System.out.println("Shape ID: " + shape.getId() + ", Area: " + shape.calArea(null));
        }
    }
}
