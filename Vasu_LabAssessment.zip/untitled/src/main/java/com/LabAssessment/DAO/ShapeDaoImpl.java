package com.LabAssessment.DAO;

import com.LabAssessment.model.Shape;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ShapeDaoImpl implements ShapeDao {
    private Map<Integer, Shape> shapeMap = new HashMap<>();

    @Override
    public void saveShape(Shape shape) {
        shapeMap.put(shape.getId(), shape);
        System.out.println("Shape saved successfully: " + shape);
    }

    @Override
    public Shape getShapeById(int id) {
        return shapeMap.get(id);
    }

    @Override
    public void displayAllShapes() {
        System.out.println("All Shapes:");
        for (Shape shape : shapeMap.values()) {
            System.out.println(shape);
        }
    }

    @Override
    public void store(Shape shape) {
        shapeMap.put(shape.getId(), shape);
        System.out.println("Shape stored successfully: " + shape);
    }

    @Override
    public void display() {
        if (shapeMap.isEmpty()) {
            System.out.println("No shapes to display.");
        } else {
            System.out.println("All Shapes:");
            for (Shape shape : shapeMap.values()) {
                System.out.println(shape);
            }
        }
    }

    @Override
    public List<Shape> getAllShapes() {
        return new ArrayList<>(shapeMap.values());
    }
}
