package com.LabAssessment.DAO;


import com.LabAssessment.model.Shape;

import java.util.List;

public interface ShapeDao {
    void saveShape(Shape shape);

    Shape getShapeById(int id);

    void displayAllShapes();

    void store(Shape shape);
    void display();

    List<Shape> getAllShapes();
}
