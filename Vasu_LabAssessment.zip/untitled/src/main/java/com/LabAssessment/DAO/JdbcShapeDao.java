package com.LabAssessment.DAO;

import com.LabAssessment.model.Shape;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;

@Repository
public class JdbcShapeDao implements ShapeDao {

    private final JdbcTemplate jdbcTemplate;

    public JdbcShapeDao(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void saveShape(Shape shape) {
        String sql = "INSERT INTO shape (area) VALUES (?)";
        jdbcTemplate.update(sql, shape.getArea());
    }

    @Override
    public Shape getShapeById(int id) {
        String sql = "SELECT * FROM shape WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, (rs, rowNum) -> {
            Shape shape = new Shape() {
                @Override
                public double calArea(Double val) {
                    return 0;
                }

                @Override
                public Integer getId() {
                    return null;
                }

                @Override
                public void setId(long id) {
                }

                @Override
                public void setArea(double area) {
                }

                @Override
                public Double getArea() {
                    return null;
                }
            };
            shape.setId(rs.getLong("id"));
            shape.setArea(rs.getDouble("area"));
            return shape;
        });
    }

    @Override
    public List<Shape> getAllShapes() {
        String sql = "SELECT * FROM shape";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Shape shape = new Shape() {
                @Override
                public double calArea(Double val) {
                    return 0;
                }

                @Override
                public Integer getId() {
                    return null;
                }

                @Override
                public void setId(long id) {
                }

                @Override
                public void setArea(double area) {
                }

                @Override
                public Double getArea() {
                    return null;
                }
            };
            shape.setId(rs.getLong("id"));
            shape.setArea(rs.getDouble("area"));
            return shape;
        });
    }

    @Override
    public void displayAllShapes() {
        List<Shape> shapes = getAllShapes();
        for (Shape shape : shapes) {
            System.out.println("Shape ID: " + shape.getId() + ", Area: " + shape.getArea());
        }
    }

    @Override
    public void store(Shape shape) {
        saveShape(shape);
    }

    @Override
    public void display() {
        displayAllShapes();
    }
}
