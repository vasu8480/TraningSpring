package LabAssessment;

import com.LabAssessment.DAO.ShapeDao;
import com.LabAssessment.DAO.ShapeDaoImpl;
import com.LabAssessment.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ShapeDaoImplTest {

    private ShapeDao shapeDao;

    @BeforeEach
    void setUp() {
        shapeDao = new ShapeDaoImpl();
    }


    @Test
    void saveShape_Positive() {
        Shape shape = new Square(1, 5.0); // Create a sample shape
        shapeDao.saveShape(shape); // Save the shape
        Shape retrievedShape = shapeDao.getShapeById(1); // Retrieve the saved shape
        assertNotNull(retrievedShape); // Check if the shape is not null
        assertEquals(shape, retrievedShape); // Check if the retrieved shape matches the saved shape
    }

    @Test
    void saveShape_Negative() {
        // Attempt to save a shape with an existing ID
        Shape shape1 = new Square(1, 5.0); // Create a sample shape
        shapeDao.saveShape(shape1); // Save the shape
        Shape shape2 = new Triangle(1, 6.0, 8.0); // Create another shape with the same ID
        assertThrows(IllegalArgumentException.class, () -> shapeDao.saveShape(shape2)); // Attempt to save the shape
    }

    @Test
    void getShapeById_Positive() {
        Shape shape = new Circle(1, 4.0); // Create a sample shape
        shapeDao.saveShape(shape); // Save the shape
        Shape retrievedShape = shapeDao.getShapeById(1); // Retrieve the saved shape
        assertNotNull(retrievedShape); // Check if the shape is not null
        assertEquals(shape, retrievedShape); // Check if the retrieved shape matches the saved shape
    }

    @Test
    void getShapeById_Negative() {
        // Attempt to retrieve a shape with an invalid ID
        Shape retrievedShape = shapeDao.getShapeById(100); // Try to retrieve a shape with a non-existing ID
        assertNull(retrievedShape); // Check if the retrieved shape is null
    }
}
