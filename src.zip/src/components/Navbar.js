import React from "react";
import { Link } from "react-router-dom";
import "./styles.css"; // Import CSS file

const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand" to="/">
          <span>Grievance</span> Portal
        </Link>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/customer-form">
                Customer Form
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/complaints">
                Complaints Page
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/redressal">
                Redressal Page
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/about-us">
                About Us
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
