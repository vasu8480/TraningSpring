import React from "react";
import "./redressalPage.css";

const RedressalPage = () => {
  return (
    <div className="container mt-4">
      <h1>Redressal Page</h1>
      <div className="redressal-content">
        <p>
          Our customer support team is dedicated to addressing your concerns and
          resolving any issues you may encounter. Please feel free to reach out
          to us via phone, email, or our online contact form.
        </p>
        <p>
          Our goal is to provide prompt and effective solutions to ensure your
          satisfaction with our products and services.
        </p>
        <div className="contact-options">
          <p>
            <strong>Phone:</strong> 7036642213
          </p>
          <p>
            <strong>Email:</strong> vasu@gmail.com
          </p>
        </div>
        <button className="btn btn-primary">Contact Us</button>
      </div>
    </div>
  );
};

export default RedressalPage;
