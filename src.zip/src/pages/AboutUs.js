import React from "react";
import "./aboutUs.css";

const AboutUs = () => {
  return (
    <div className="container mt-4">
      <h1>About Us</h1>
      <div className="about-content">
        <section className="intro-section">
          <h2>Our Story</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut
            blandit nunc. Praesent non magna eu arcu congue rhoncus. Nam vitae
            commodo metus. Ut eget lectus nec urna malesuada scelerisque.
          </p>
          <p>
            Curabitur eu metus et metus vestibulum tristique. Morbi commodo
            turpis sed ex ultrices blandit. Duis ac nisi ut enim suscipit
            ultricies.
          </p>
        </section>
        <section className="team-section">
          <h2>Our Team</h2>
          <div className="team-members">
            <div className="team-member">
              <img src="../images/rohit.jpg" alt="Nurukurthi Vasu" />
              <h3>Nurukurthi Vasu</h3>
              <p>CEO</p>
            </div>
            <div className="team-member">
              <img src="rohit.jpg" alt="Team Member 2" />
              <h3>Rohit</h3>
              <p>CTO</p>
            </div>
            {/* Add more team members as needed */}
          </div>
        </section>
        <section className="mission-section">
          <h2>Our Mission</h2>
          <p>
            Our mission is to provide innovative solutions that empower
            individuals and businesses to achieve their goals efficiently and
            effectively.
          </p>
        </section>
        <section className="contact-section">
          <h2>Contact Us</h2>
          <p>For inquiries and feedback, please feel free to contact us at:</p>
          <p>Email: vasu8480@gmail.com</p>
          <p>Phone: 7036642213</p>
        </section>
      </div>
    </div>
  );
};

export default AboutUs;
