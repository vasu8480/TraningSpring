// HomePage.js
import React from 'react';

const HomePage = () => {
  return (
    <div className="container mt-4">
      <h1>Welcome to Customer Grievance Portal</h1>
      <p>This portal is designed to address customer grievances and provide solutions in a timely manner.</p>
      <p>Please explore the options in the navigation menu to access different features of the portal.</p>
    </div>
  );
};

export default HomePage;
