import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./complaints.css";

const ComplaintsPage = () => {
  const [complaints, setComplaints] = useState([]);
  const [filteredComplaints, setFilteredComplaints] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("date"); // 'date' or 'priority'
  const [currentPage, setCurrentPage] = useState(1);
  const [complaintsPerPage] = useState(5);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch complaints from an API or database
    // Example API call: fetchComplaints()
    const mockComplaints = [
      {
        id: 1,
        title: "Slow Internet",
        description: "Internet speed is very slow",
        priority: "Low",
        date: "2022-04-01",
      },
      {
        id: 2,
        title: "Payment Issue",
        description: "Payment was deducted twice",
        priority: "High",
        date: "2022-04-03",
      },
      // Add more sample complaints as needed
    ];
    setComplaints(mockComplaints);
    setFilteredComplaints(mockComplaints);
  }, []);

  // Handle sorting of complaints
  useEffect(() => {
    const sortedComplaints = [...filteredComplaints].sort((a, b) => {
      if (sortBy === "date") {
        return new Date(b.date) - new Date(a.date);
      } else if (sortBy === "priority") {
        return a.priority.localeCompare(b.priority);
      }
      return 0;
    });
    setFilteredComplaints(sortedComplaints);
  }, [filteredComplaints, sortBy]);

  // Handle pagination
  const indexOfLastComplaint = currentPage * complaintsPerPage;
  const indexOfFirstComplaint = indexOfLastComplaint - complaintsPerPage;
  const currentComplaints = filteredComplaints.slice(
    indexOfFirstComplaint,
    indexOfLastComplaint
  );

  // Change page
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // Handle search
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1); // Reset pagination to first page when searching
    const filtered = complaints.filter(
      (complaint) =>
        complaint.title.toLowerCase().includes(e.target.value.toLowerCase()) ||
        complaint.description
          .toLowerCase()
          .includes(e.target.value.toLowerCase())
    );
    setFilteredComplaints(filtered);
  };

  // Navigate to Complaint Details Page
  const goToComplaintDetails = (id) => {
    navigate(`/complaints/${id}`);
  };

  return (
    <div className="container mt-4">
      <h1>Complaints Page</h1>
      {/* Search input */}
      <input
        type="text"
        className="form-control mb-3"
        placeholder="Search complaints..."
        value={searchTerm}
        onChange={handleSearch}
      />
      {/* Sorting options */}
      <div className="mb-3">
        <select
          className="form-select"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
        >
          <option value="date">Sort by Date</option>
          <option value="priority">Sort by Priority</option>
        </select>
      </div>
      {/* Complaints list */}
      {currentComplaints.map((complaint) => (
        <div
          className="card mb-3"
          key={complaint.id}
          onClick={() => goToComplaintDetails(complaint.id)}
        >
          <div className="card-body">
            <h5 className="card-title">{complaint.title}</h5>
            <p className="card-text">{complaint.description}</p>
            <p className="card-text">
              <small className="text-muted">
                Priority: {complaint.priority}
              </small>
            </p>
          </div>
        </div>
      ))}
      {/* Pagination */}
      <nav aria-label="Page navigation example">
        <ul className="pagination">
          {Array.from(
            {
              length: Math.ceil(filteredComplaints.length / complaintsPerPage),
            },
            (_, i) => (
              <li
                className={`page-item ${i + 1 === currentPage ? "active" : ""}`}
                key={i}
              >
                <button className="page-link" onClick={() => paginate(i + 1)}>
                  {i + 1}
                </button>
              </li>
            )
          )}
        </ul>
      </nav>
    </div>
  );
};

export default ComplaintsPage;
