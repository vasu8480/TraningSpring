// App.js
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import CustomerForm from "./pages/CustomerForm";
import ComplaintsPage from "./pages/ComplaintsPage";
import RedressalPage from "./pages/RedressalPage";
import AboutUs from "./pages/AboutUs";
import "./App.css"; // Import CSS file for global styles

function App() {
  return (
    <Router>
      <div>
        <Navbar />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/customer-form" element={<CustomerForm />} />
          <Route path="/complaints" element={<ComplaintsPage />} />
          <Route path="/redressal" element={<RedressalPage />} />
          <Route path="/about-us" element={<AboutUs />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
