package com.stude.Assigment2.Repository;

import com.stude.Assigment2.Entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {
}
