package com.stude.Assigment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assigment2Application {

	public static void main(String[] args) {
		SpringApplication.run(Assigment2Application.class, args);
	}

}
