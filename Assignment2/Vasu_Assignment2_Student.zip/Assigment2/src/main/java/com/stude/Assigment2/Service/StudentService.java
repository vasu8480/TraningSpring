package com.stude.Assigment2.Service;

import com.stude.Assigment2.Entity.Student;
import com.stude.Assigment2.Repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student saveStudent(Student student) {
        // Calculate result based on subject marks
        calculateResult(student);
        return studentRepository.save(student);
    }

    private void calculateResult(Student student) {
        int subject1Marks = student.getSubject1Marks();
        int subject2Marks = student.getSubject2Marks();
        int subject3Marks = student.getSubject3Marks();

        // Calculate average marks
        double averageMarks = (subject1Marks + subject2Marks + subject3Marks) / 3.0;

        // Determine class based on average marks
        if (averageMarks >= 50) {
            student.setResult("First Class");
        } else if (averageMarks >= 40) {
            student.setResult("Second Class");
        } else if (averageMarks >= 30) {
            student.setResult("Third Class");
        } else {
            student.setResult("Fail");
        }
    }


}
