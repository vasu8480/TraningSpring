package com.stude.Assigment2.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private int subject1Marks;
    private int subject2Marks;
    private int subject3Marks;
    private String result;

    // Constructors
    public Student(String name, int subject1Marks, int subject2Marks, int subject3Marks) {
        this.name = name;
        this.subject1Marks = subject1Marks;
        this.subject2Marks = subject2Marks;
        this.subject3Marks = subject3Marks;
    }



    // Getters and Setters
    // Additional methods if needed
}
