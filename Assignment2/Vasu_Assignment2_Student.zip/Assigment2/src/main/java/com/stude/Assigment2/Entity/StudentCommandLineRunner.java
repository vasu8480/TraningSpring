package com.stude.Assigment2.Entity;

import com.stude.Assigment2.Entity.Student;
import com.stude.Assigment2.Repository.StudentRepository;
import com.stude.Assigment2.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class StudentCommandLineRunner implements CommandLineRunner {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private StudentService studentService;

    @Override
    public void run(String... args) throws Exception {
        // Insert sample data
        Student student1 = new Student("John", 85, 75, 85);
        Student student2 = new Student("Alice", 29, 55, 30);
        Student student3 = new Student("Bob", 50, 65, 60);

        studentService.saveStudent(student1);
        studentService.saveStudent(student2);
        studentService.saveStudent(student3);
    }
}
