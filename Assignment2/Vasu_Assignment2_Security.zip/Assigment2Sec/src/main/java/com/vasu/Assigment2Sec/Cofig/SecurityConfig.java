package com.vasu.Assigment2Sec.Cofig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.DefaultSecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12); // Set strength to 12 for stronger encryption
    }

    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder passwordEncoder) {
        UserDetails obj1 = User.builder()
                .username("vasu")
                .password(passwordEncoder.encode("vasu"))
                .roles("USER")
                .build();

        UserDetails obj2 = User.builder()
                .username("rohit")
                .password(passwordEncoder.encode("rohit"))
                .roles("USER")
                .build();

        UserDetails adminobj = User.builder()
                .username("admin")
                .password(passwordEncoder.encode("12345"))
                .roles("ADMIN")
                .build();

        return new InMemoryUserDetailsManager(obj1, adminobj, obj2);
    }

    @Bean
    DefaultSecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .authorizeRequests(authorize -> authorize
                        .anyRequest().authenticated())
                .httpBasic(Customizer.withDefaults())
                .logout(logout -> logout
                        .logoutUrl("/logout") // Customize logout URL if needed
                        .logoutSuccessUrl("/") // Redirect to homepage after logout
                        .deleteCookies("JSESSIONID")) // Delete cookies upon logout
                .formLogin(); // Enable form-based authentication

        return http.build();
    }
}
